package com.merchant.merchantapp.exception;

public class InvalidMerchantByMobNumException extends RuntimeException {

    public InvalidMerchantByMobNumException(String exMsg) {
        super(exMsg);
    }
}




