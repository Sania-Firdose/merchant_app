package com.merchant.merchantapp.repository;

import com.merchant.merchantapp.model.Merchant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MerchantRepository extends JpaRepository<Merchant,Integer> {

    public Merchant findByMerchantName(String name);

    @Query(value="select * from merchant where mob_num=:mobNum",nativeQuery = true)
    public Merchant getByMobNum(@Param("mobNum") String mobNum);

    @Query(value="select merchant_name,address from merchant where account_number=:accountNumber",nativeQuery = true)
    public List<Object[]> findMerchantNameAndAddressByAccNo(@Param("accountNumber")String accountNumber);

    @Query("select m from Merchant m where m.mobNum=:mobNum")
    public Merchant findMerchantByMobNum(@Param("mobNum") String mobNum);

    @Query("select new Merchant(m.merchantName,m.email) from Merchant m where m.id=:id")
    public Merchant findMerchantNameAndMailById(@Param("id")int id);

    @Query("select m from Merchant m where m.accountNumber=:accountNumber")
    public Merchant findMerchantByAccNo(@Param("accountNumber") String accNo);
}
