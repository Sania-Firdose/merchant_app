package com.merchant.merchantapp.validator;

import com.merchant.merchantapp.model.Product;
import org.springframework.stereotype.Component;

@Component
public class Validator {

    public boolean validate(Product product)
    {

        return product.getProductCategory().equalsIgnoreCase("Electronic Device");
    }

}
