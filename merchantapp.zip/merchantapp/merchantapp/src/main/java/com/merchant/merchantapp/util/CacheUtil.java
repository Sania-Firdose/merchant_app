package com.merchant.merchantapp.util;

import com.merchant.merchantapp.model.Merchant;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class CacheUtil {
    Map<String,Merchant> map = null;

    @PostConstruct
    public void init()
    {
        map = new ConcurrentHashMap();
    }

    public boolean isKeyPresent(String key)
    {
        return map.containsKey(key);
    }

    public Merchant getMerchant(String key)
    {
        return map.get(key);
    }

    public void insertKeyAndValue(String key,Merchant merchant)
    {
        map.put(key,merchant);
    }
}
