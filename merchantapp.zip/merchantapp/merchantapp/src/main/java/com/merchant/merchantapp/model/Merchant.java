package com.merchant.merchantapp.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name="Merchant")
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_DEFAULT)  // Ignore fields with default values
public class Merchant {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String accountNumber;
    private String merchantName;
    private String mobNum;
    private String email;
    private int age;
    private String address;

    public Merchant(String merchantName,String email)
    {
        this.merchantName=merchantName;
        this.email=email;
    }


}
