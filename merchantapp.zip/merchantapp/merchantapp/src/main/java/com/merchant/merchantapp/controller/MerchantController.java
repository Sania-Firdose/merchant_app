package com.merchant.merchantapp.controller;

import com.merchant.merchantapp.model.Merchant;
import com.merchant.merchantapp.model.MerchantProductReq;
import com.merchant.merchantapp.model.MerchantProductRes;
import com.merchant.merchantapp.model.Product;
import com.merchant.merchantapp.service.MerchantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/merchant")
public class MerchantController {

    @Autowired
    private MerchantService merchantService;

    @PostMapping("/register")
    public ResponseEntity<Merchant> merchantRegister(@RequestBody Merchant merchant)
    {
         Merchant merchantObj=merchantService.merchantRegister(merchant);
         return new ResponseEntity<Merchant>(merchantObj,HttpStatus.OK);
    }

    @GetMapping("/findById/{id}")
    public ResponseEntity<Merchant> findByMerchantId(@PathVariable int id)
    {
        Optional<Merchant> merchantObj=merchantService.findByMerchantId(id);
        return new ResponseEntity(merchantObj,HttpStatus.OK);
    }

    @GetMapping("/findByName/{name}")
    public ResponseEntity<Merchant> findByMerchantName(@PathVariable String name)
    {
        Merchant merchantObj=merchantService.findByMerchantName(name);
        return new ResponseEntity<Merchant>(merchantObj,HttpStatus.OK);
    }
    @GetMapping("/getByMobNum/{mobNum}")
    public ResponseEntity<Merchant> getByMobNum(@PathVariable String mobNum)
    {
        Merchant merchantObj=merchantService.getByMobNum(mobNum);
        return new ResponseEntity<Merchant>(merchantObj,HttpStatus.OK);
    }

    @PostMapping("/saveAll")
    public ResponseEntity<List<Merchant>> saveAllMerchantDetails(@RequestBody List<Merchant> merchantList)
    {
        List<Merchant>  merchantObj = merchantService.saveAllMerchantDetails(merchantList);
        return new ResponseEntity(merchantObj,HttpStatus.OK);
    }

    @GetMapping("/findMerchantNameAndAddressByAccNo/{accountNumber}")
    public ResponseEntity<List<Object[]>> findMerchantNameAndAddressByAccNo(@PathVariable String accountNumber)
    {
        List<Object[]> merchantObj = merchantService.findMerchantNameAndAddressByAccNo(accountNumber);
        return new ResponseEntity(merchantObj,HttpStatus.OK);
    }

    @GetMapping("/findMerchantByAccNo/{accNo}")
    public ResponseEntity<Merchant> findMerchantByAccNo(@PathVariable String accNo)
    {
        Merchant merchantObj = merchantService.findMerchantByAccNo(accNo);
        return new ResponseEntity<Merchant>(merchantObj,HttpStatus.OK);
    }

    @GetMapping("/findMerchantByMobNum/{MobNum}")
    public ResponseEntity<Merchant> findMerchantByMobNum(@PathVariable String MobNum)
    {
        Merchant merchantObj = merchantService.findMerchantByMobNum(MobNum);
        return new ResponseEntity<Merchant>(merchantObj,HttpStatus.OK);
    }

    @GetMapping("/findMerchantNameAndMailById/{id}")
    public ResponseEntity<Merchant> findMerchantNameAndMailById(@PathVariable int id) {
        Merchant merchantObj = merchantService.findMerchantNameAndMailById(id);
        return new ResponseEntity(merchantObj,HttpStatus.OK);
    }

    @PostMapping("/saveProduct")
    public ResponseEntity<Product> saveProduct(@RequestBody Product product)
    {
        Product productObj = merchantService.saveProduct(product);
        return new ResponseEntity(productObj,HttpStatus.OK);
    }

    @PostMapping("/saveMerchantAndProduct")
    public ResponseEntity<MerchantProductRes> saveMerchantAndProduct(@RequestBody MerchantProductReq merchantProductReq)
    {
        MerchantProductRes merchantProductResp =merchantService.saveMerchantAndProduct(merchantProductReq);
        return new ResponseEntity(merchantProductResp,HttpStatus.OK);
    }


//    @GetMapping("/test")
//    public Product test()
//    {
//        Product product = new Product();
//        product.setProductCode("123");
//        return product;
//    }

//    @GetMapping("/test")
//    public Merchant test()
//    {
//        Merchant merchant = new Merchant();
//        merchant.setAccountNumber("123");
//        return merchant;
//    }


}
