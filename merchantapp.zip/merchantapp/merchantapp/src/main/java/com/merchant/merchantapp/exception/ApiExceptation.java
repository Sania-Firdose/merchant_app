package com.merchant.merchantapp.exception;

import com.merchant.merchantapp.model.ErrorModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ApiExceptation {
    @ExceptionHandler(InvalidProductException.class)
    public ResponseEntity<ErrorModel> handleProductException(InvalidProductException invalidProductException) {
        ErrorModel errorModel = ErrorModel.builder().errorCode("Err-001").errorMessage(invalidProductException.getMessage()).build();
        return new ResponseEntity(errorModel, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(InvalidMerchantByMobNumException.class)
    public ResponseEntity<ErrorModel> handleMobNumException(InvalidMerchantByMobNumException invalidMerchantByMobNumException) {
        ErrorModel errorModel = ErrorModel.builder().errorCode("Err-002").errorMessage(invalidMerchantByMobNumException.getMessage()).build();
        return new ResponseEntity(errorModel, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(InvalidAccNoException.class)
    public ResponseEntity<ErrorModel> handleAccNoException(InvalidAccNoException invalidAccNoException) {
        ErrorModel errorModel = ErrorModel.builder().errorCode("Err-003").errorMessage(invalidAccNoException.getMessage()).build();
        return new ResponseEntity(errorModel, HttpStatus.BAD_REQUEST);
    }
}
