package com.merchant.merchantapp.exception;

public class InvalidAccNoException extends RuntimeException{

    public InvalidAccNoException(String exMsg) {
        super(exMsg);
    }

}


