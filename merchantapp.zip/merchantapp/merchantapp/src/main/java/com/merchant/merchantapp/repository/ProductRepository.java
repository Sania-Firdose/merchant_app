package com.merchant.merchantapp.repository;

import com.merchant.merchantapp.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product,Integer> {
}
