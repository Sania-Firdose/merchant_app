package com.merchant.merchantapp.service;

import com.merchant.merchantapp.model.Merchant;
import com.merchant.merchantapp.model.MerchantProductReq;
import com.merchant.merchantapp.model.MerchantProductRes;
import com.merchant.merchantapp.model.Product;

import java.util.List;
import java.util.Optional;

public interface MerchantService {
    public Merchant merchantRegister(Merchant merchant);
    public Optional<Merchant> findByMerchantId(int id);
    public Merchant findByMerchantName(String name);
    public Merchant getByMobNum(String mobNum);
    public List<Object[]> findMerchantNameAndAddressByAccNo(String accountNumber);
    public Merchant findMerchantByMobNum(String mobNum);
    public Merchant findMerchantNameAndMailById(int id);
    public List<Merchant> saveAllMerchantDetails(List<Merchant> merchantList);
    public Product saveProduct(Product product);
    public MerchantProductRes saveMerchantAndProduct(MerchantProductReq merchantProductReq);
    public Merchant findMerchantByAccNo(String accNo);
}
