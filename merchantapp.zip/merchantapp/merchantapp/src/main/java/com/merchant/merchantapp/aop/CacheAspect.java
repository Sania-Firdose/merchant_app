package com.merchant.merchantapp.aop;


import com.merchant.merchantapp.model.Merchant;
import com.merchant.merchantapp.util.CacheUtil;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class CacheAspect {

    @Autowired
    private CacheUtil cacheUtil;

    @Around("execution(* com.merchant.merchantapp.service.MerchantServiceImpl.findMerchantByMobNum(..))")
    public Merchant execute(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        String className = proceedingJoinPoint.getTarget().getClass().getName();
        String methodName = proceedingJoinPoint.getSignature().getName();
        String parameter = (String) proceedingJoinPoint.getArgs()[0];
        System.out.println("Class Name = "+className);
        System.out.println("Method Name = "+methodName);
        System.out.println("Parameter = "+parameter);
        Merchant merchant=null;
        if(cacheUtil.isKeyPresent(parameter)) {
            merchant=cacheUtil.getMerchant(parameter);
            System.out.println("Data is retrieved from Cache Storage");}
        else {
            merchant = (Merchant) proceedingJoinPoint.proceed();
            System.out.println("Data is retrieved from Database Storage");
            cacheUtil.insertKeyAndValue(parameter,merchant);}
        return merchant;
    }
}
