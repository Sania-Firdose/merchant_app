package com.merchant.merchantapp.aop;

import com.merchant.merchantapp.exception.InvalidMerchantByMobNumException;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class ValidateAspect {

    @Before("execution(* com.merchant.merchantapp.service.MerchantServiceImpl.findMerchantByMobNum(..))")
    public void execute(JoinPoint joinPoint)
    {
        String mobNum = (String) joinPoint.getArgs()[0];
        if(mobNum.length()>10) {
            throw new InvalidMerchantByMobNumException("Invalid Mobile Number Entered! Please Enter Valid Mobile Number ");
        }
        System.out.println("Mobile Number = "+mobNum);

    }

    @After("execution(* com.merchant.merchantapp.service.MerchantServiceImpl.findMerchantByMobNum(..))")
    public void execute()
    {
        System.out.println(" Mobile Number is a Valid");
    }
}