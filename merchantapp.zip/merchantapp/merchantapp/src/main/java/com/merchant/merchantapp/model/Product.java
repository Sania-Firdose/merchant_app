package com.merchant.merchantapp.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name ="Product")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Product {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private int productId;
    private String productName;
    private String productCode;
    private String productCategory;
    private String productBrand;
    private Double price;
    private String color;
    private String description;
}
