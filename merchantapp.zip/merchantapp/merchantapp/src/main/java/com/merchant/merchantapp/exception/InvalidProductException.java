package com.merchant.merchantapp.exception;

public class InvalidProductException extends RuntimeException{
    public InvalidProductException(String errorMessage)
    {
        super(errorMessage);
    }
}
