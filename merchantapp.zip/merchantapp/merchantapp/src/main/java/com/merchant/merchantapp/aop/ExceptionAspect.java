package com.merchant.merchantapp.aop;

import com.merchant.merchantapp.exception.InvalidAccNoException;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class ExceptionAspect {

    @AfterThrowing(pointcut="execution(* com.merchant.merchantapp.service.MerchantServiceImpl.findMerchantByAccNo(..))",throwing="e")
    public void execute(InvalidAccNoException e)
    {
        System.out.println("Some error ocurred while excecuting : "+e.getMessage());
    }
}
