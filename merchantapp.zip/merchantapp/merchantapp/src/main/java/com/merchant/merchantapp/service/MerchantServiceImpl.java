package com.merchant.merchantapp.service;

import com.merchant.merchantapp.exception.InvalidAccNoException;
import com.merchant.merchantapp.exception.InvalidProductException;
import com.merchant.merchantapp.model.Merchant;
import com.merchant.merchantapp.model.MerchantProductReq;
import com.merchant.merchantapp.model.MerchantProductRes;
import com.merchant.merchantapp.model.Product;
import com.merchant.merchantapp.repository.MerchantRepository;
import com.merchant.merchantapp.repository.ProductRepository;
import com.merchant.merchantapp.util.CacheUtil;
import com.merchant.merchantapp.validator.Validator;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MerchantServiceImpl implements MerchantService{

    @Autowired
    private MerchantRepository merchantRepo;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private Validator validator;

    @Autowired
    private CacheUtil cacheUtil;

    @Override
    public Merchant merchantRegister(Merchant merchant) {
        merchant.setAccountNumber(getRandomNumber());
        return merchantRepo.save(merchant);
    }

    private String getRandomNumber()
    {
        double randomNo=Math.random();
        String merchantAccNo = Double.toString(randomNo).substring(2);
        return merchantAccNo;
    }

    @Override
    public Optional<Merchant> findByMerchantId(int id) {
        return merchantRepo.findById(id);
    }

    @Override
    public Merchant findByMerchantName(String name) {
        return merchantRepo.findByMerchantName(name);
    }

    @Override
    public Merchant getByMobNum(String mobNum) {
        return merchantRepo.getByMobNum(mobNum);
    }

    @Override
    public List<Merchant> saveAllMerchantDetails(List<Merchant> merchantList) {
        merchantList.stream().forEach(merchant->merchant.setAccountNumber(getRandomNumber()));
        return merchantRepo.saveAll(merchantList);
    }

    @Override
    public List<Object[]> findMerchantNameAndAddressByAccNo(String accountNumber) {

        return merchantRepo.findMerchantNameAndAddressByAccNo(accountNumber);
    }

    @Override
    public Merchant findMerchantByMobNum(String mobNum) {
        return merchantRepo.findMerchantByMobNum(mobNum);
    }

    @Override
    public Merchant findMerchantNameAndMailById(int id) {
        return merchantRepo.findMerchantNameAndMailById(id);
    }

    @Override
    public Product saveProduct(Product product) {
        product.setProductCode(getRandomNumber());
        return productRepository.save(product);
    }

    @Override
    @Transactional
    public MerchantProductRes saveMerchantAndProduct(MerchantProductReq merchantProductReq) {

        Product productResp = null;
        Merchant merchant = merchantProductReq.getMerchant();
        Product product = merchantProductReq.getProduct();

        merchant.setAccountNumber(getRandomNumber());
        Merchant merchantResp=merchantRepo.save(merchant);

        if(validator.validate(product))
        {
            product.setProductCode(getRandomNumber());
            productResp=productRepository.save(product);
        }
        else
        {
            throw new InvalidProductException("Invalid Product Category! Please enter valid product details");
        }
        MerchantProductRes merchantProductRes = MerchantProductRes.builder().accountNumber(merchantResp.getAccountNumber()).productCode(productResp.getProductCode()).build();
        return merchantProductRes;
    }

    @Override
    public Merchant findMerchantByAccNo(String accNo) {

        Merchant merchant =  merchantRepo.findMerchantByAccNo(accNo);
        if (merchant==null)
        {
            throw new InvalidAccNoException(" There is no record present for the account number entered ");
        }
        return merchant;
    }
}
